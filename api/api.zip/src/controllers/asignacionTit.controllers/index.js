const createAsignacionTit = require('./createAsignacionTit.js');
const delAsignacionTit = require('./delAsignacionTit.js');

module.exports={
    createAsignacionTit,
    delAsignacionTit
}