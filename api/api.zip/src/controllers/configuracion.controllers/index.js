const getConfiguracion = require('./getConfiguracion.js');
const getConfigComponente = require('./getConfigComponente.js');
const updateActivoComponente = require('./updateActivoComponente.js');


module.exports={
    getConfiguracion,
    getConfigComponente,
    updateActivoComponente
};