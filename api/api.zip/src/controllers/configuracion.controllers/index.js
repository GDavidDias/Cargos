const getConfiguracion = require('./getConfiguracion.js');

module.exports={
    getConfiguracion
};