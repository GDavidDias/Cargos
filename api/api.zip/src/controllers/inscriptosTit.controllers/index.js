const getAllInscriptosTit = require('./getAllInscriptosTit.js');
const editInscriptoTit = require('./editInscriptoTit.js');

module.exports={
    getAllInscriptosTit,
    editInscriptoTit
}