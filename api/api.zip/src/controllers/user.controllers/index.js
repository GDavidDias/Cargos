const validateUser = require('./validateuser');

module.exports={
    validateUser
}