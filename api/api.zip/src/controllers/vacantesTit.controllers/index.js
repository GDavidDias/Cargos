const getAllVacantesTit = require('./getAllVacantesTit.js');
const getVacanteAsignadaTit = require('./getVacanteAsignadaTit.js');

module.exports = {
    getAllVacantesTit,
    getVacanteAsignadaTit
};