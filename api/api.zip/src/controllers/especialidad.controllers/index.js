const getEspecidalidades = require('./getEspecialidades.js');

module.exports={
    getEspecidalidades
}