const getEspecidalidades = require('./getEspecialidades.js');
const updateEspecialidadVisorTit = require('./updateEspecialidadVisorTit.js');

module.exports={
    getEspecidalidades,
    updateEspecialidadVisorTit
}