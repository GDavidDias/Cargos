// const app = require('./app.js');

// app.listen(3000);
// console.log('servidor iniciado Back Cargos.');

const server = require('./app.js');

server.listen(3000);
console.log('servidor iniciado Back Cargos.');