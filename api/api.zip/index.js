const app = require('./app.js');

app.listen(3000);
console.log('servidor iniciado Back Cargos.');